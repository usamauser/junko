<?php session_start(); 
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - contact page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.html">home</a></li>
                            <li>about us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--contact map start-->
    
    <!--contact map end-->

    <!--contact area start-->
    <div class="contact_area">
        <div class="container">
            <div class="row">
				<?php
	                              $q="SELECT * FROM cmpny_cntact";
							      $r=mysqli_query($con,$q);
							      while($row=mysqli_fetch_array($r))
								  { ?>
                <div class="col-lg-6 col-md-12">
					
                    <div class="contact_message content">
                        <h3>contact us</h3>
                        <p><?php echo $row['msg']?></p>
                        <ul>
                            <li><i class="fa fa-fax"></i> Address: <?php echo $row['address']?></li>
                            <li><i class="fa fa-envelope-o"> </i> Email: <?php echo $row['email']?></li>
                            <li><i class="fa fa-phone"></i> Phone :<?php echo $row['Phone']?></li>
                        </ul>
                    </div>
                </div>
				<?php } ?>
                <div class="col-lg-6 col-md-12">
                    <div class="contact_message form">
                        <h3>Tell us your project</h3>
                        <form class="contact-form" method="POST">
                            <p>
                                <label> Your Name (required)</label>
                                <input name="name" placeholder="Name *" type="text">
                            </p>
                            <p>
                                <label> Your Email (required)</label>
                                <input name="email" placeholder="Email *" type="email">
                            </p>
                            <p>
                                <label> Subject</label>
                                <input name="subject" placeholder="Subject *" type="text">
                            </p>
                            <div class="contact_textarea">
                                <label> Your Message</label>
                                <textarea placeholder="Message *" name="message" class="form-control2"></textarea>
                            </div>
                            <button name="btn10" type="submit"> Send</button>
                        </form>
						
						<?php 
						    include('connect.php'); 
							if(isset($_REQUEST['btn10']))
							{
								$name = $_REQUEST['name'];
								$e_mail = $_REQUEST['email'];
								$subject = $_REQUEST['subject'];
								$message = $_REQUEST['message'];
								$date = date ('j/M/Y');

								$insert = "INSERT INTO 
								contact(id,u_name,u_email,sub,msg,date,status) VALUES (NULL,'$name','$e_mail','$subject','$message','$date',0)";
								mysqli_query($con,$insert);
								echo "<script>window.location.replace('contact.php')</script>";

							}
								?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--contact area end-->

    <?php include('footer.php') ?>
	
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAdWLY_Y6FL7QGW5vcO3zajUEsrKfQPNzI"></script>
    <script src="https://www.google.com/jsapi"></script>
    <script src="assets/js/map.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>



</body>

</html>