<?php session_start();	
?>
<?php 
 $catgry = $_GET['cat_id'];
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - shop</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<style>
	
	.btn-outline-info {
    color: #1953b4;
    border-color: #1953b4;
	margin: 50px;
}
	.btn-outline-info:hover
	{background-color: #1953b4;
		border-color: ##1953b4;
	}
	
	
	</style>
<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Camera & Video </li>
                            <li>shop</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--shop  area start-->
    <div class="shop_area shop_reverse mt-60 mb-60">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-9 col-md-12">
                    <!--shop wrapper start-->
                    <!--shop toolbar start-->
                    <div class="shop_toolbar_wrapper">
                        <div class="shop_toolbar_btn">

                            <button data-role="grid_3" type="button" class="active btn-grid-3" data-toggle="tooltip"
                                title="3"></button>

                            <button data-role="grid_4" type="button" class=" btn-grid-4" data-toggle="tooltip"
                                title="4"></button>

                        </div>
                    </div>
                    <!--shop toolbar end-->
                    <div class="row shop_wrapper">
						<?php
								 
	                             $q4="SELECT * FROM product WHERE cat_id='$catgry'";
							     $r4=mysqli_query($con,$q4);
							     while($row1=mysqli_fetch_array($r4))
					 { 			
						?>
						
                        <div class="col-lg-4 col-md-4 col-12 ">
							<form method="post">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="product-details.php?p_id=<?php echo $row1['p_id'] ?>"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row1['image'])?>" alt=""></a>
                                        <div class="action_links">
											<ul>
												<li>
													<?php if(isset($_SESSION['SESS-ID'])) {?>
											<button style="background: none; border: none;" type="submit" name="wish<?php echo $row1['p_id'] ?>"><a class="fa fa-heart-o" data-toggle="tooltip" data-placement="top" title="Add to Whishlist"></a></button>
													<?php } else {?> 
									<a href="login.php" title="Login for Add to Wishlist"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
									<?php }?>
											</li></ul>
                                        </div>
                                        
											<?php if(isset($_SESSION['SESS-ID'])) {?>
									<div class="btn btn-outline-info">
                                            <button style="background: none; border: none;" type="submit" name="cart3<?php echo $row1['p_id'] ?>">Add to cart</button>
											<?php } else {?> 
								<div class="add_to_cart">
								<a href="login.php"  title="Login to Add To Cart">Add to cart</a>
									</div>
								<?php }?>
                                        </div>
                                    </div>
                                    <div class="product_content grid_content">
                                        <div class="price_box">
                                            <h5>Price: <span class="current_price">$<?php $g=$row1['sale_price'];
													if($g<=0)
											   {
												  echo $row1['price'];
												   
											   }
										       else
											   {
												  echo $row1['sale_price']; 
												   
											   }
												?></span></h5>
                                        </div>
                                        
                                        <h3 class="product_name grid_name"><a href="product-details.php?p_id=<?php echo $row1['p_id'] ?>"><?php echo $row1['p_name'] ?></a></h3>
                                    </div>
                                    <div class="product_content list_content">
                                        <div class="left_caption">
                                            <div class="price_box">
                                                <h5>Price: <span class="current_price">$<?php  $g=$row1['sale_price'];
													if($g<=0)
											   {
												  echo $row1['price'];
												   
											   }
										       else
											   {
												  echo $row1['sale_price']; 
												   
											   }
													?></span></h5>
                                            </div>
                                            <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row1['p_id'] ?>"></a><?php echo $row1['p_name'] ?></a></h3>
                                            <div class="product_desc">
                                                <p><?php echo $row1['description'] ?></p>
                                            </div>
                                        </div>
                                        <div class="right_caption">
											
                                            <div class="btn btn-outline-info">
											<?php if(isset($_SESSION['SESS-ID'])){?>
                                            <button style="background: none; border: none;" type="submit" name="cart4<?php echo $row1['p_id'] ?>">Add to cart</button>
											<?php } else {?>
											<div class="add_to_cart">
										<a href="login.php"  title="Login to Add To Cart">Add to cart</a>
										</div>
											<?php } ?>
                                        </div>
                                            <div class="action_links">
												<ul>
													<li>
													<?php if(isset($_SESSION['SESS-ID'])){?>
													<button style="background: none; border: none;" type="submit" name="wish1<?php echo $row1['p_id'] ?>"><a class="fa fa-heart-o" data-toggle="tooltip" data-placement="top" title="Add to Whishlist"></a></button>
														<?php } else {?>
														<a href="login.php" title="Login for Add to Wishlist"><i class="fa fa-heart" aria-hidden="true"></i></a>
														<?php } ?>
													</li>
												</ul>
                                            </div>
											
                                        </div>
                                    </div>
                                </figure>
                            </article>
						</form>
                        </div>
					
					<?php 
						 
						 $pid=$row1['p_id'];
					  	 $qty=$row1['quantity'];
					if(isset($_REQUEST['cart3'.$pid]))	{
						$uid=$_SESSION['SESS-ID'];
						$o_id=0;
						if($row1['sale_price']<=0) {
							$p_price=$row1['price'];
						}
						else{
							$p_price=$row1['sale_price'];
						}
						$qry1 = "SELECT * FROM cart WHERE u_id = '$uid' AND p_id = '$pid' AND status='0'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
													$up="SELECT * FROM cart WHERE p_id='$pid' AND u_id='$uid'";
													$u=mysqli_query($con, $up);
													while($r3=mysqli_fetch_array($u))
													{ 
													  
													 $qnty=$r3['p_qty']+1;
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $qrr = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
										         	mysqli_query($con,$qrr);
													 
													} 
													
												}
						else{
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,o_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('shop.php?cat_id=$catgry')</script>";
						}
					} 
						 ?>
					<?php 
						 
						 $pid=$row1['p_id'];
					  	 $qty=$row1['quantity'];
					if(isset($_REQUEST['cart4'.$pid]))	{
						$uid=$_SESSION['SESS-ID'];
						$o_id=0;
						if($row1['sale_price']<=0) {
							$p_price=$row1['price'];
						}
						else{
							$p_price=$row1['sale_price'];
						}
						$qry1 = "SELECT * FROM cart WHERE u_id = '$uid' AND p_id = '$pid' AND status='0'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
													$up="SELECT * FROM cart WHERE p_id='$pid' AND u_id='$uid'";
													$u=mysqli_query($con, $up);
													while($r3=mysqli_fetch_array($u))
													{ 
													  
													 $qnty=$r3['p_qty']+1;
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $qrr = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
										         	mysqli_query($con,$qrr);
													 
													} 
													
												}
						else{
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,o_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('shop.php?cat_id=$catgry')</script>";
						}
					} 
						 ?>
						
					<?php
									   
										$pid=$row1['p_id'];
									   if(isset($_REQUEST['wish'.$pid]))
													   {
										$uid=$_SESSION['SESS-ID'];
										$qry1 = "SELECT * FROM wishlist WHERE u_id = '$uid' AND p_id = '$pid'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
												 
												}
										        else
												{
													$qrr= "INSERT INTO wishlist (id, p_id,u_id) VALUES ( NULL, '$pid', '$uid')";
																mysqli_query($con,$qrr);
																echo "<script> window.location.replace('index.php')</script>";
												}
																
													   }
										
								?>
						<?php
									   
										$pid=$row1['p_id'];
									   if(isset($_REQUEST['wish1'.$pid]))
													   {
										$uid=$_SESSION['SESS-ID'];
										$qry1 = "SELECT * FROM wishlist WHERE u_id = '$uid' AND p_id = '$pid'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
												 
												}
										        else
												{
													$qrr= "INSERT INTO wishlist (id, p_id,u_id) VALUES ( NULL, '$pid', '$uid')";
																mysqli_query($con,$qrr);
																echo "<script> window.location.replace('index.php')</script>";
												}
																
													   }
										
								?>
					<?php  }?>
                    </div>

                    
                    <!--shop toolbar end-->
                    <!--shop wrapper end-->
                </div>
            </div>
        </div>
    </div>
    <!--shop  area end-->

    <?php include('footer.php') ?>

    <!-- modal area start-->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">
                                    <div class="tab-content product-details-large">
                                        <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product1.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab2" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product2.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab3" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product3.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab4" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product5.jpg" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal_tab_button">
                                        <ul class="nav product_navactive owl-carousel" role="tablist">
                                            <li>
                                                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab"
                                                    aria-controls="tab1" aria-selected="false"><img
                                                        src="assets/img/product/product1.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab2" role="tab"
                                                    aria-controls="tab2" aria-selected="false"><img
                                                        src="assets/img/product/product2.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link button_three" data-toggle="tab" href="#tab3"
                                                    role="tab" aria-controls="tab3" aria-selected="false"><img
                                                        src="assets/img/product/product3.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab4" role="tab"
                                                    aria-controls="tab4" aria-selected="false"><img
                                                        src="assets/img/product/product5.jpg" alt=""></a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2>Handbag feugiat</h2>
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price">$64.99</span>
                                        <span class="old_price">$78.99</span>
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste
                                            laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam
                                            in quos qui nemo ipsum numquam, reiciendis maiores quidem aperiam, rerum vel
                                            recusandae </p>
                                    </div>
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                            <h2>size</h2>
                                            <select class="select_option">
                                                <option selected value="1">s</option>
                                                <option value="1">m</option>
                                                <option value="1">l</option>
                                                <option value="1">xl</option>
                                                <option value="1">xxl</option>
                                            </select>
                                        </div>
                                        <div class="variants_color">
                                            <h2>color</h2>
                                            <select class="select_option">
                                                <option selected value="1">purple</option>
                                                <option value="1">violet</option>
                                                <option value="1">black</option>
                                                <option value="1">pink</option>
                                                <option value="1">orange</option>
                                            </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form action="#">
                                                <input min="0" max="100" step="2" value="1" type="number">
                                                <button type="submit">add to cart</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal area end-->

    <script src="assets/js/plugins.js"></script>

    <script src="assets/js/main.js"></script>



</body>
</html>