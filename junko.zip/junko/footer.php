<style>

input:focus{
		border-color:  #0063d1;
		transition: 1s;
}
	</style>
<?php include('connect.php') ?>
<!--footer area start-->
    <footer class="footer_widgets">
        <div class="footer_top">
            <div class="container">
                <div class="row">
					<?php
	                              $q="SELECT * FROM cmpny_cntact";
							      $r=mysqli_query($con,$q);
							      while($row=mysqli_fetch_array($r))
								  { ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="widgets_container contact_us">
                            <div class="footer_logo">
                                <a href="#"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row['img'])?>" alt=""></a>
                            </div>
                            <div class="footer_contact">
                                <p><?php echo $row['des'] ?></p>
                                <p>Address: <?php echo $row['address'] ?></p>
                                <p>Mobile: <?php echo $row['Phone'] ?></p>
                                <p>Support: <?php echo $row['email'] ?></p>
                               
                            </div>
                        </div>
                    </div>
					<?php } ?>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="widgets_container widget_menu">
                            <h3>Information</h3>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
									<li><a href="faq.php">FAQ</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="widgets_container widget_menu">
                            <h3>My Account</h3>
                            <div class="footer_menu">
								<?php if(isset($_SESSION['SESS-ID'])){?>
                                <ul>
                                    <li><a href="user_info.php">My Account</a></li>
                                    <li><a href="userorder_history.php">Order History</a></li>
                                    <li><a href="user_wishlist.php">Wish List</a></li>
                                </ul>
								<?php } else {?>
								<p>Please Login <a href="login.php"><span><b style="color: #1953B4;">Here</b></span></a></p>
								<?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="widgets_container newsletter">
                            <h3>Follow Us</h3>
                            <div class="footer_social_link">
								<?php
	                              $q="SELECT * FROM follow";
							      $r=mysqli_query($con,$q);
							      while($row=mysqli_fetch_array($r))
								  { ?>
                                <ul>
                                    <li><a class="facebook" href="<?php echo $row['fb'] ?>" title="Facebook"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a class="twitter" href="<?php echo $row['twitter'] ?>" title="Twitter"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a class="instagram" href="<?php echo $row['insta'] ?>" title="instagram"><i
                                                class="fa fa-instagram"></i></a></li>
                                    <li><a class="linkedin" href="<?php echo $row['linkedin'] ?>" title="linkedin"><i class="fa fa-linkedin"></i></a>
                                    </li>
                                </ul>
								<?php } ?>
                            </div>
                            <div class="subscribe_form">
                                <h3>Join Our Newsletter Now</h3>
                                <form method="post">
                                    <input type="email" name="email" placeholder="Your email address..." />
                                    <button name="btn1" type="submit">Subscribe!</button>
                                </form>
								<?php 
											if(isset($_REQUEST['btn1']))
											{
											$email=$_REQUEST['email'];
											$date=date('j/M/Y');
											$qry="INSERT INTO newsletter(id,email,date)
											VALUES(null, '$email','$date')";	
											mysqli_query($con,$qry);	
											//echo "<script>window.location.replace('contact-us.php')</script>";
											
										    }
										
									?>
                                <!-- mailchimp-alerts Start -->
                                <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                    <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                    <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                                </div><!-- mailchimp-alerts end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer_bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="copyright_area">
                            <p class="copyright-text">&copy; 2021 <a href="index.php">Junko</a>. Made with <i
                                    class="fa fa-heart text-danger"></i> by <a href="https://hasthemes.com/"
                                    target="_blank">Muhammad Usama Farooq</a> </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--footer area end-->