<?php
require_once("session.php");
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - login</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
.account_form button {
		  height: 40px;
		  border-radius: 5px;
}
input:focus{
		border-color:  #0063d1;
		transition: 1s;
}
	</style>
<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Sign In</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!-- customer login start -->
    <div class="customer_login mt-60">
        <div class="container">
            <div class="row">
                <!--login area start-->
                <div class="col-lg-3 col-md-3"></div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" >
                    <div class="account_form">
                        <h1 style="color: #1953b4; padding-bottom: 30px;" align="center" >Sign In</h1>
                        <form method="post" style="box-shadow: 2px 2px 10px 2px #ebebeb; padding-top: 40px;">
                            <p>
                                <label>Email Address<span>*</span></label>
                                <input class="inpt1" name="email" type="text" placeholder="Enter here">
                            </p>
                            <p>
                                <label>Password <span>*</span></label>
                                <input class="inpt1" name="password" type="password" placeholder="Enter here">
                            </p>
							<p align="center">
                                 <div align="center">
                                   <button type="submit"  name="btn3" style="width: 80%;">login</button>
                                </div>
                            </p>
                            <p>
                               <div align="center">
                                <a href="#" style="color: #1953b4;">Lost your password?</a>
								
                            </div>
                            </p>
                        </form>
			<?php
										if(isset($_REQUEST['btn3']))
							            {
								$email = $_REQUEST['email'];
								$password = $_REQUEST['password'];
								
							$insert1 = "SELECT * FROM register WHERE email='$email' AND password='$password'";
							$r=mysqli_query($con,$insert1);
							$row=mysqli_fetch_assoc($r);
							if(mysqli_num_rows($r)>0)
								{
session_start();
session_regenerate_id();
$_SESSION['SESS-ID'] = $row['u_id'];
//$_SESSION['SESS-NAME'] = $row['fname'];
session_write_close();
//$uid=$_SESSION['SESS-ID'];								
//echo "<script>alert('$uid')</script>";								
header("location:index.php");
								}
								else{
									 echo "Login error.Try again";
								}
									}?>			
			
			
			
                    </div>
                </div>
			
                <!--login area start-->
            </div>
        </div>
    </div>
    <!-- customer login end -->

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>

    <script src="assets/js/main.js"></script>
    


</body>
</html>