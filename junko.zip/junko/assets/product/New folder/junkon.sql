-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2021 at 03:31 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `junkon`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional`
--

CREATE TABLE IF NOT EXISTS `additional` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `additional`
--


-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `name`, `status`, `sort`) VALUES
(1, 'Sony', 1, 1),
(2, 'Samsung', 1, 2),
(3, 'Breakout', 1, 3),
(4, 'Nokia', 1, 5),
(5, 'Oppo', 1, 4),
(6, 'Panasonic', 1, 6),
(7, 'Apple', 1, 7),
(8, 'JBL', 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_price` varchar(11) NOT NULL,
  `p_qty` int(11) NOT NULL,
  `p_total` varchar(11) NOT NULL,
  `p_tax` int(11) NOT NULL,
  `p_ship` int(11) NOT NULL,
  `g_total` varchar(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `u_id`, `order_id`, `p_id`, `p_price`, `p_qty`, `p_total`, `p_tax`, `p_ship`, `g_total`, `status`) VALUES
(7, 1, 5, 10, '100.00', 1, '100', 0, 0, '100', 1),
(8, 1, 5, 9, '35.00', 1, '35', 0, 0, '35', 1),
(9, 1, 6, 8, '100.00', 3, '300', 0, 0, '300', 1),
(13, 1, 0, 1, '22.50', 13, '292.5', 0, 0, '292.5', 1),
(14, 1, 0, 7, '50.00', 6, '300', 0, 0, '300', 1),
(15, 1, 0, 1, '22.50', 13, '292.5', 0, 0, '292.5', 1),
(16, 1, 0, 13, '100.00', 1, '100', 0, 0, '100', 1),
(28, 1, 7, 1, '22.50', 13, '292.5', 0, 0, '292.5', 1),
(29, 1, 7, 8, '100.00', 3, '300', 0, 0, '300', 1),
(34, 1, 8, 7, '50.00', 6, '300', 0, 0, '300', 1),
(35, 1, 14, 7, '50.00', 6, '300', 0, 0, '300', 1),
(36, 1, 14, 1, '22.50', 1, '22.5', 0, 0, '22.5', 1),
(37, 1, 1, 1, '22.50', 1, '22.5', 0, 0, '22.5', 1),
(38, 1, 1, 7, '50.00', 6, '300', 0, 0, '300', 1),
(39, 1, 2, 8, '100.00', 1, '100', 0, 0, '100', 1),
(40, 1, 0, 7, '50.00', 6, '300', 0, 0, '300', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `name`, `status`, `sort`, `sub_id`) VALUES
(1, 'Home Audio & Theathers', 1, 1, 1),
(2, 'TV & Videos', 1, 2, 1),
(3, 'Camera, Photos & Video', 1, 3, 1),
(4, 'Cellphone & Accessories', 1, 4, 1),
(5, 'Headphone', 1, 5, 1),
(6, 'Video Games', 1, 6, 1),
(7, 'Wireless Speakers', 1, 7, 1),
(8, 'Other Electronics', 1, 8, 1),
(9, 'Digital Cables ', 1, 1, 2),
(10, 'Audio & Video Cables', 1, 2, 2),
(11, 'Batteries', 1, 3, 2),
(12, 'T-Shirts', 1, 1, 3),
(13, 'Jackets', 1, 2, 3),
(14, 'Shirts', 1, 3, 3),
(15, 'Denims & Jeans', 1, 4, 3),
(16, 'Shoes', 1, 5, 3),
(17, 'Kurta & Pajama''s', 1, 6, 3),
(18, 'Others', 1, 7, 3),
(19, 'Shirts', 1, 1, 4),
(20, 'Jeans', 1, 2, 4),
(21, 'Shalwar Kameez', 1, 3, 4),
(22, 'Shoes', 1, 4, 4),
(23, 'Jackets', 1, 5, 4),
(24, 'Computer & Tablets', 1, 1, 6),
(25, 'Laptops', 1, 2, 6),
(26, 'Monitors', 1, 3, 6),
(27, 'Networking', 1, 4, 6),
(28, 'Drive & Storage', 1, 5, 6),
(29, 'Computer Components', 1, 6, 6),
(30, 'Security & Protection', 1, 7, 6),
(31, 'Accessories', 1, 8, 6),
(32, 'Chairs', 1, 1, 7),
(33, 'Tables', 1, 2, 7),
(34, 'Sofa Sets', 1, 3, 7),
(35, 'Others', 1, 4, 7),
(36, 'Lights', 1, 1, 8),
(37, 'Flowers & Decoration', 1, 2, 8),
(38, 'Home Carpets', 1, 3, 8),
(39, 'Watches', 1, 1, 9),
(40, 'Rings & Chains', 1, 2, 9),
(41, 'Belts & Bracelets', 1, 3, 9),
(42, 'Sunglasses', 1, 4, 9),
(43, 'Smart Phones', 1, 1, 10),
(44, 'Keypad Phones', 1, 2, 10),
(45, 'Used Phones', 1, 3, 10),
(46, 'Charger & Wires ', 1, 1, 11),
(47, 'Phone Covers', 1, 2, 11),
(48, 'Batteries', 1, 3, 11),
(49, 'Touch & Screens', 1, 4, 11),
(50, 'Beauty Creams', 1, 1, 12),
(51, 'Facewashes', 1, 2, 12),
(52, 'Oils', 1, 3, 12),
(54, 'Kid''s Towel', 1, 1, 5),
(55, 'T-shirts ', 1, 2, 5),
(56, 'Shoes ', 1, 3, 5),
(57, 'Jeans & Nikers', 1, 4, 5),
(58, 'Shirts', 1, 0, 14);

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE IF NOT EXISTS `checkout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `l_name` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip_code` int(11) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `total` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`id`, `u_id`, `f_name`, `l_name`, `country`, `address`, `city`, `state`, `zip_code`, `phone`, `email`, `total`, `status`, `date`) VALUES
(1, 1, 'atif', 'nadeem', 'Pakistan', 'Home#147, street#4, Umar Block Shadab Town', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '72.5', 2, '12/Apr/2021'),
(2, 1, 'atif', 'nadeem', 'Pakistan', 'eewe', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '100', 1, '12/Apr/2021'),
(3, 1, 'atif', 'nadeem', 'Pakistan', 'eewe', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '300', 0, '21/Apr/2021'),
(4, 1, 'atif', 'nadeem', 'Pakistan', 'eewe', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '300', 1, '21/Apr/2021'),
(5, 1, 'atif', 'nadeem', 'Pakistan', 'eewe', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '300', 0, '22/Apr/2021'),
(6, 1, 'atif', 'nadeem', 'Pakistan', 'eewe', 'hjhj', 'Alabama', 87788, '+928768687668', 'atifch6464@gmail.com', '300', 0, '22/Apr/2021');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(100) NOT NULL,
  `u_email` varchar(255) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `msg` text NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `u_name`, `u_email`, `sub`, `msg`, `date`, `status`) VALUES
(1, 'atif nadeem', 'atifch6464@gmail.com', '6786', 'hjytrfgv', '19/Apr/2021', 0),
(2, 'atif nadeem', 'atifch6464@gmail.com', 'kjhb', ',kjhytgfcvb nmkjhygv\r\n', '19/Apr/2021', 0),
(3, 'usama farooq', 'usamaking283@gmail.com', 'nice project', 'lmkbh', '', 0),
(4, 'ahsan', 'ahsan@gmail.com', 'nice project', 'dwjcbhw', '', 0),
(5, 'man', 'man283@gmail.com', 'nice project', 'wkdncscwjixc', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `main_cat`
--

CREATE TABLE IF NOT EXISTS `main_cat` (
  `main_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`main_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `main_cat`
--

INSERT INTO `main_cat` (`main_id`, `name`, `status`, `sort`) VALUES
(1, 'Consumer Electronics', 1, 1),
(2, 'Clothing', 1, 2),
(3, 'Home & Kitchen', 1, 3),
(4, 'Watches  & Jewelery', 1, 4),
(5, 'Computer & Technology', 1, 5),
(6, 'Phones & Accessories', 1, 6),
(7, 'Health & Beauty', 1, 7),
(8, 'Cars and Parts', 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `date`) VALUES
(1, '', '19/Apr/2021'),
(2, 'atifch646@gmail.com', '19/Apr/2021'),
(3, 'atifch646@gmail.com', '19/Apr/2021');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `card_no` varchar(200) NOT NULL,
  `expiry_date` varchar(200) NOT NULL,
  `cvv` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `order_id`, `u_id`, `total_price`, `date`, `name`, `card_no`, `expiry_date`, `cvv`, `status`) VALUES
(1, 14, 1, '172.5', '12/Apr/2021', 'Atif  Nadeem', '567657', '8/2025', 645, 0),
(2, 1, 1, '72.5', '12/Apr/2021', 'Atif  Nadeem', '867556676456476576', '7/2018', 123, 0),
(3, 2, 1, '72.5', '12/Apr/2021', 'Atif  Nadeem', '563534', '12/2028', 565, 0),
(4, 2, 1, '100', '12/Apr/2021', 'Atif  Nadeem', '563534', '12/2028', 565, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `price` varchar(50) NOT NULL,
  `sale_price` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `review` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `SKU` varchar(255) NOT NULL,
  `sold_by` varchar(255) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `image`, `p_name`, `price`, `sale_price`, `quantity`, `description`, `review`, `status`, `SKU`, `sold_by`, `cat_id`, `brand_id`) VALUES
(1, 'assets\\img\\product\\samsung_65_4k_smart_curved_uhd_led_tv_65nu7300__2.jpg', 'Samsung 65" 4K Smart Curved UHD LED TV (65NU7300) - Without Warranty', '500', '470', 40, 'Junko brings you the best price for Samsung 65" 4K Smart Curved UHD LED TV (65NU7300) with express shipping all over Pakistan.', '10', 1, '457664778-UK', 'Young Shop', 1, 2),
(2, 'assets\\img\\product\\panasonic_dvd_home_theater_system_sc-xh333_15000.jpg', 'Panasonic 5.1CH DVD Home Theater System (SC-XH333)', '300', '290', 40, 'Junko brings you the best price for Panasonic 5.1CH DVD Home Theater System (SC-XH333) with 1 year official warranty and express shipping all over Pakistan.', '4', 1, '75758768-TY', 'Daraz.pk', 2, 6),
(3, 'assets\\img\\product\\product7.jpg', 'Cool Boy Mart Wireless Wifi IP CCTV Security Camera', '250', '210', 20, 'Junko brings you the best price for Cool Boy Mart Wireless Wifi IP CCTV Security Camera with express shipping all over Pakistan.', '13', 1, '4576647RWX', 'Daraz.pk', 3, 1),
(4, 'assets\\img\\product\\product1.jpg', 'Samsung S9 128GB/4GB', '900', '880', 28, 'Versions: G960F (Europe, Global Single-SIM); G960F/DS (Europe, Global Dual-SIM); G960U (USA); G960W (Canada); G9600 (China, LATAM)', '15', 1, '757587624-QSW', 'Whatmobiles', 4, 2),
(5, 'assets\\img\\product\\product23.jpg', 'iphone 7 256GB/3GB', '1030', '990', 34, 'Versions: G960F (Europe, Global Single-SIM); G960F/DS (Europe, Global Dual-SIM); G960U (USA); G960W (Canada); G9600 (China, LATAM)', '38', 1, '7576576-PY', 'Apple', 4, 7),
(6, 'assets\\img\\product\\product6.jpg', 'Sony Wireless Bluetooth Headphone Black (STN-16)', '230', '200', 30, 'Junko brings you the best price for Sony Wireless Bluetooth Headphone Black (STN-16) with express shipping all over Pakistan.', '15', 1, '4576647988OPO', 'Young Shop', 5, 1),
(7, 'assets\\img\\product\\product11.jpg', 'Sony DualShock 4 Wireless Controller for PS4 - Purple', '250', '239', 20, 'Junko brings you the best price for Sony DualShock 4 Wireless Controller for PS4 - Steel Black with express shipping all over Pakistan.', '4', 1, '87537652IYH', 'Daraz.pk', 6, 1),
(8, 'assets\\img\\product\\product19.jpg', 'JBL Xtreme 2 Portable Wireless Bluetooth Speaker Midnight Black', '140', '130', 34, 'Junko brings you the best price for JBL Xtreme 2 Portable Wireless Bluetooth Speaker Midnight Black with express shipping all over Pakistan.', '21', 1, '7576576-PY', 'Go Pro', 7, 8);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE IF NOT EXISTS `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `image`, `status`, `sort`, `p_id`) VALUES
(1, 'assets\\img\\product\\samsung_65_4k_smart_curved_uhd_led_tv_65nu7300__2.jpg', 1, 1, 1),
(2, 'assets\\img\\product\\un65nu7300fxza_003_r_perspective_black_2_3.jpg', 1, 2, 1),
(3, 'assets\\img\\product\\un65nu7300fxza_005_l_side_black_2_3.jpg', 1, 3, 1),
(4, 'assets\\img\\product\\un65nu7300fxza_010_detail1_black_2_3.jpg', 1, 4, 1),
(5, 'assets\\img\\product\\R52ac7c9c0dc9e9ba40f4df186608e56e.jpg', 1, 1, 2),
(6, 'assets\\img\\product\\ht-f453hk-4.jpg', 1, 2, 2),
(7, 'assets\\img\\product\\OIP.jpg', 1, 3, 2),
(8, 'assets\\img\\product\\product8.jpg', 1, 1, 3),
(9, 'assets\\img\\product\\184_9.jpg', 1, 2, 3),
(10, 'assets\\img\\product\\61KDv2r3jjL._AC_SL1001_.jpg', 1, 3, 3),
(11, 'assets\\img\\product\\61bfOVpFaUL._AC_SL1001_.jpg', 1, 4, 3),
(12, 'assets\\img\\product\\product2.jpg', 1, 1, 4),
(13, 'assets\\img\\product\\products_223699086.jpg', 1, 2, 4),
(14, 'assets\\img\\product\\products_546503554.jpg', 1, 3, 4),
(15, 'assets\\img\\product\\products_1585428982.jpg', 1, 4, 4),
(16, 'assets\\img\\product\\iphone-7-plus-128gb-lte-4g-red-special-edition-3gb-ram_10014291_1_1490343196.jpg', 1, 1, 5),
(17, 'assets\\img\\product\\iphone-7-plus-128gb-lte-4g-red-special-edition-3gb-ram_10014291_2_1490343202.jpg', 1, 2, 5),
(18, 'assets\\img\\product\\iphone-7-plus-128gb-lte-4g-red-special-edition-3gb-ram_10014291_3_1490343211.jpg', 1, 3, 5),
(19, 'assets\\img\\product\\iphone-7-plus-128gb-lte-4g-red-special-edition-3gb-ram_10014291_4_1490343219.jpg', 1, 4, 5),
(20, 'assets\\img\\product\\product5.jpg', 1, 1, 6),
(21, 'assets\\img\\product\\BLUE-903x808-500x500.jpg', 1, 2, 6),
(22, 'assets\\img\\product\\beats2-1000x1000-1000x1000__55493_zoom-500x500.jpg', 1, 3, 6),
(23, 'assets\\img\\product\\Red-10-scaled-500x500.jpg', 1, 4, 6),
(24, 'assets\\img\\product\\product12.jpg', 1, 1, 7),
(25, 'assets\\img\\product\\productbig.jpg', 1, 2, 7),
(26, 'assets\\img\\product\\1568207181_1504379.jpg', 1, 3, 7),
(27, 'assets\\img\\product\\electricpurpleproductshot.jpg.94e7d9c170.989x800x800.jpg', 1, 4, 7),
(28, 'assets\\img\\product\\download.jpg', 1, 1, 8),
(29, 'assets\\img\\product\\jbl_xtreme_2_portable_wireless_bluetooth_speaker_midnight_black_2_5.jpg', 1, 2, 8),
(30, 'assets\\img\\product\\jbl_xtreme_2_portable_wireless_bluetooth_speaker_midnight_black_3_5.jpg', 1, 3, 8),
(31, 'assets\\img\\product\\jbl-xtreme-2-portable-wireless-bluetooth-speaker-midnight-black.jpg', 1, 4, 8);

-- --------------------------------------------------------

--
-- Table structure for table `product_spec`
--

CREATE TABLE IF NOT EXISTS `product_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `details` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `product_spec`
--

INSERT INTO `product_spec` (`id`, `name`, `details`, `sort`, `status`, `p_id`) VALUES
(1, 'Style', 'Army and Hook', 1, 1, 7),
(2, 'Weight', '2 pounds', 2, 1, 7),
(3, 'Color', 'Green, Black, Blue', 3, 1, 7),
(4, 'Waterproof', 'Yes', 4, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` int(11) NOT NULL,
  `cpassword` int(11) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `zip_code` int(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `dob` date NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `lastname`, `email`, `password`, `cpassword`, `address`, `city`, `state`, `country`, `zip_code`, `phone`, `dob`, `date`) VALUES
(2, 'Usama', 'farooq', 'usamaking283@gmail.com', 12345, 12345, 'mwknckw', 'sahiwal', 'punjab', 'pakistan', 57000, 123456, '2000-06-21', '0000-00-00'),
(3, 'usama', 'farooq', 'usamaking283@gmail.com', 123, 123, 'jxnsjxnjsnxjsnxs', 'xsixnsi', 'sxnsixns', 'Pakistan', 57000, 1234567, '0000-00-00', '0000-00-00'),
(4, 'usama', 'farooq', 'usamaking283@gmail.com', 123, 123, 'jxnsjxnjsnxjsnxs', 'xsixnsi', 'sxnsixns', 'Pakistan', 57001, 1234567, '0000-00-00', '0000-00-00'),
(5, 'usama', 'farooq', 'usamaking283@gmail.com', 123, 123, 'jxnsjxnjsnxjsnxs', 'xsixnsi', 'sxnsixns', 'Pakistan', 57000, 1234567, '0000-00-00', '0000-00-00'),
(6, 'usama', 'farooq', 'usamaking283@gmail.com', 1234, 1234, '', 'xsixnsi', 'sxnsixns', 'Pakistan', 57001, 1234567, '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `review` varchar(20) NOT NULL,
  `p_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `email`, `des`, `review`, `p_id`, `u_id`) VALUES
(1, 'uvbu', 'hjjh@gmail.com', '4t4r4rererer', '5', 1, 0),
(2, 'atif', 'aa@gma.com', 'good product', '5', 1, 2),
(3, 'usama', 'ss@gma.com', 'nice', '4', 1, 3),
(4, 'ali', 'aa@gma.com', 'well good', '1', 1, 4),
(5, 'hh', 'hjjh@gmail.com', 'kuhjb', '4', 1, 5),
(6, 'uvbu', 'ss@gma.com', 'yuhbv', '3', 1, 6),
(7, 'Atif nadeem h', 'atifch64@gmail.com', '', '0', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE IF NOT EXISTS `size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`id`, `p_id`, `name`, `description`) VALUES
(1, 1, 'L', 'none'),
(2, 1, 'XL', 'none'),
(3, 1, 'S', 'none'),
(4, 1, 'M', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `sub_cat`
--

CREATE TABLE IF NOT EXISTS `sub_cat` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `main_id` int(11) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `sub_cat`
--

INSERT INTO `sub_cat` (`sub_id`, `name`, `status`, `sort`, `main_id`) VALUES
(1, 'Electronics', 1, 1, 1),
(2, 'Accessories and Parts', 1, 2, 1),
(3, 'Men''s', 1, 1, 2),
(4, 'Women''s', 1, 2, 2),
(5, 'Kid''s', 1, 3, 2),
(6, 'Computer and Technology', 1, 1, 5),
(7, 'Furniture', 1, 1, 3),
(8, 'Decoration', 1, 2, 3),
(9, 'Men''s & Women''s', 1, 1, 4),
(10, 'Phones', 1, 1, 6),
(11, 'Accessories', 1, 2, 6),
(12, 'Health & Beauty', 1, 1, 7),
(14, 'Old', 1, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `position` varchar(100) NOT NULL,
  `fb` text NOT NULL,
  `insta` text NOT NULL,
  `linkedin` text NOT NULL,
  `twitter` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `image`, `name`, `position`, `fb`, `insta`, `linkedin`, `twitter`, `status`) VALUES
(1, 'img/users/our-team/1.jpg', 'Robert J', 'CEO', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', 1),
(2, 'img/users/our-team/2.jpg', 'Alex Bhatti', 'Product Manager', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', 'https://www.facebook.com/', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `p_id`, `u_id`) VALUES
(1, 8, 1),
(2, 8, 0),
(6, 1, 1),
(7, 27, 1);
