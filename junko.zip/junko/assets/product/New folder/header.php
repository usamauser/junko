<?php include('connect.php') ?>
<!--header area start-->
    <!--Offcanvas menu area start-->
    
    <!--Offcanvas menu area end-->
    <header>
        <div class="main_header ">
            <!--header top start-->
            <div class="header_top">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="support_info">
                                <p>Email Address: <a style="color:#0063d1; ">fusama22@gmail.com</a></p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="top_right text-right">
								 <ul>
								<?php if(isset($_SESSION['SESS_ID'])){ ?>
								<a href="#">WelCome </a>								
									<?php } else { ?>
									 <li>
								<a href="login.php"><i class="fa fa-user" aria-hidden="true"></i> Sign In </a>
								</li>
									 <li>
									<a href="register.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Join Us </a>
								</li>
									 <?php } ?>
								 </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--header top start-->
            <!--header middel start-->
            <div class="header_middle">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-6">
                            <div class="logo">
                                <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-6">
                            <div class="middel_right">
                                <div class="search_container">
                                    <form action="#">
                                        <div class="hover_category">
                                            <select class="select_option" name="select" id="categori1">
                                                <option selected value="1">All Categories</option>
                                                <option value="2">Accessories</option>
                                                <option value="3">Accessories & More</option>
                                                <option value="4">Butters & Eggs</option>
                                                <option value="5">Camera & Video </option>
                                                <option value="6">Mornitors</option>
                                                <option value="7">Tablets</option>
                                                <option value="8">Laptops</option>
                                                <option value="9">Handbags</option>
                                                <option value="10">Headphone & Speaker</option>
                                                <option value="11">Herbs & botanicals</option>
                                                <option value="12">Vegetables</option>
                                                <option value="13">Shop</option>
                                                <option value="14">Laptops & Desktops</option>
                                                <option value="15">Watchs</option>
                                                <option value="16">Electronic</option>
                                            </select>
                                        </div>
                                        <div class="search_box">
                                            <input placeholder="Search product..." type="text">
                                            <button type="submit">Search</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="middel_right_info">
									
								<?php if(isset($_SESSION['SESS_ID'])){ ?>
								<?php } else { ?>
                                    <div class="header_wishlist">
                                        <a href="wishlist.php"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                                        <span class="wishlist_quantity">
										<?php 
										   $uid= $_SESSION['SESS-ID'];
										   $query = "SELECT id FROM wishlist where u_id='$uid' AND status='0'"; 
													$result = mysqli_query($con,$query); 
													if ($result) { 
														echo $row = mysqli_num_rows($result); 
													} 

										   ?>
										</span>
										
                                    </div>
                                    <div class="mini_cart_wrapper">
                                        <a href="javascript:void(0)"><i class="fa fa-shopping-bag"
                                                aria-hidden="true"></i>$147.00 <i class="fa fa-angle-down"></i></a>
                                        <span class="cart_quantity">
										<?php 
										   $uid= $_SESSION['SESS-ID'];
										   $query = "SELECT id FROM cart where u_id='$uid' AND status='0'"; 
													$result = mysqli_query($con, $query); 
													if ($result) { 
														echo $row = mysqli_num_rows($result); 
													} 

										   ?>
										</span>
										
                                        <!--mini cart-->
                                        <div class="mini_cart">
												<?php
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM cart WHERE status = '0' AND u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   { 
									 $pid=$row['p_id'];
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {	
										
										?>       
											<div class="cart_item">
                                                <div class="cart_img">
                                                  <a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><img src="<?php echo $r['image'] ?>" alt=""></a>
                                                </div>
                                                <div class="cart_info">
                                                    <a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a>
                                                    <p><?php echo $row['p_qty'] ?><span><?php echo $row['p_price'] ?></span></p>
                                                </div>
                                                <div class="cart_remove">
                                                    <a href="Index.php?delete=<?php echo $row['id']; ?>"><i class="ion-android-close"></i></a>
                                                </div>
											</div>
                                              
											<?php } } ?>
                                        <?php
									if(isset($_GET['delete']))
									{
										$d=$_GET['delete'];
										$delete="DELETE FROM cart where id='$d'";
										mysqli_query($con,$delete);
										echo "<script>window.location.replace('Index.php')</script>";
									}
									
									?>
												 
												
                                            <div class="mini_cart_table">
                                                <div class="cart_total mt-10">
                                                    <span>total:</span>
                                                    <span class="price">$
													<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(g_total) as g_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['g_tot'];
										}?>
													</span>
                                                </div>
                                            </div>

                                            <div class="mini_cart_footer">
                                                <div class="cart_button">
                                                    <a href="cart.php">View cart</a>
                                                </div>
                                                <div class="cart_button">
                                                    <a href="checkout.php">Checkout</a>
                                                </div>

                                            </div>
												
											
										</div>
                                        <!--mini cart end-->
                                    </div>
									
									
									<?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--header middel end-->
            <!--header bottom satrt-->
            <div class="main_menu_area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-12">
                            <div class="categories_menu">
                                <div class="categories_title">
                                    <h2 class="categori_toggle">ALL CATEGORIES</h2>
                                </div>
                                <div class="categories_menu_toggle">
                                    <ul>
						<?php
                        $q="SELECT * FROM main_cat WHERE status = '1' ORDER BY sort ASC ";
                        $r=mysqli_query($con,$q);
                        while($cat1=mysqli_fetch_array($r))
						{ ?> 
                                        <li class="menu_item_children"><a><?php echo $cat1['name'] ?> <i class="fa fa-angle-right"></i></a>
                                            <ul class="categories_mega_menu">
						       <?php
                                    $main_id=$cat1['main_id'];
                                    $q1="SELECT * FROM sub_cat WHERE main_id='$main_id' and  status = '1' ORDER BY sort ASC ";
                                    $ru=mysqli_query($con,$q1);
                                    while($cat2=mysqli_fetch_array($ru)){
                                    ?>
                                                <li class="menu_item_children"><a><?php echo $cat2['name'] ?></a>
                                                    <ul class="categorie_sub_menu">
											<?php
                                            $sub_id=$cat2['sub_id'];
                                            $q2="SELECT * FROM category WHERE sub_id= '$sub_id' and  status = '1' ORDER BY sort ASC";
                                            $ru1=mysqli_query($con,$q2);
                                            while ($cat3=mysqli_fetch_array($ru1)) {
                                                # code...
                                            ?>			
                                              <li><a href="shop.php?cat_id=<?php echo $cat3['cat_id']; ?>"><?php echo $cat3['name'] ?></a></li>
														
										    <?php } ?>				
                                                    </ul>
                                                </li>
                                     <?php } ?>      
                                            </ul>
                                        </li>
                                <?php  } ?>                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-12">
                            <div class="main_menu menu_position">
                                <nav>
                                    <ul>
										
										
                                        <li><a class="active" href="index.php">home</a></li>
										<li><a href="order_history.php">Orders</a></li>
                                        <li><a href="about.php">about Us</a></li>
                                        <li><a href="contact.php"> Contact Us</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--header bottom end-->
        </div>
    </header>
    <!--header area end-->
    <!--sticky header area start-->
    <div class="sticky_header_area sticky-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <div class="logo">
                        <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                    </div>
                </div>
				 
                <div class="col-lg-8">
                    <div class="sticky_header_right menu_position">
                        <div class="main_menu">
                            <nav>
                                <ul>
                                    <li><a class="active" href="index.php">home</a></li>
										<li><a href="order_history.php">Orders</a></li>
                                        <li><a href="about.php">about Us</a></li>
                                        <li><a href="contact.php"> Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="middel_right_info">
                            <div class="header_wishlist">
                                <a href="wishlist.php"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                                <span class="wishlist_quantity">3</span>
                            </div>
                            <div class="mini_cart_wrapper">
                                <a href="javascript:void(0)"><i class="fa fa-shopping-bag"
                                        aria-hidden="true"></i>$147.00 <i class="fa fa-angle-down"></i></a>
                                <span class="cart_quantity">2</span>
                                <!--mini cart-->
                                <div class="mini_cart">
                                    <div class="cart_item">
                                        <div class="cart_img">
                                            <a href="#"><img src="assets/img/s-product/product.jpg" alt=""></a>
                                        </div>
                                        <div class="cart_info">
                                            <a href="#">Sit voluptatem rhoncus sem lectus</a>
                                            <p>Qty: 1 X <span> $60.00 </span></p>
                                        </div>
                                        <div class="cart_remove">
                                            <a href="#"><i class="ion-android-close"></i></a>
                                        </div>
                                    </div>
                                    <div class="cart_item">
                                        <div class="cart_img">
                                            <a href="#"><img src="assets/img/s-product/product2.jpg" alt=""></a>
                                        </div>
                                        <div class="cart_info">
                                            <a href="#">Natus erro at congue massa commodo</a>
                                            <p>Qty: 1 X <span> $60.00 </span></p>
                                        </div>
                                        <div class="cart_remove">
                                            <a href="#"><i class="ion-android-close"></i></a>
                                        </div>
                                    </div>
                                    <div class="mini_cart_table">
                                        <div class="cart_total">
                                            <span>Sub total:</span>
                                            <span class="price">$138.00</span>
                                        </div>
                                        <div class="cart_total mt-10">
                                            <span>total:</span>
                                            <span class="price">$138.00</span>
                                        </div>
                                    </div>

                                    <div class="mini_cart_footer">
                                        <div class="cart_button">
                                            <a href="cart.php">View cart</a>
                                        </div>
                                        <div class="cart_button">
                                            <a href="checkout.php">Checkout</a>
                                        </div>

                                    </div>

                                </div>
                                <!--mini cart end-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--sticky header area end-->