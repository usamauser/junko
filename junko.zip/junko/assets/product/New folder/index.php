<?php session_start(); ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Electronics eCommerce HTML Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS 
    ========================= -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

   <?php include('header.php') ?>

    <!--slider area start-->
    <section class="slider_section mb-70">
        <div class="slider_area owl-carousel">
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider1.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h1> best skin</h1>
                                <h2>qled 75 inch q7f</h2>
                                <p>exclusive offer <span> 20% off </span> this week</p>
                                <a class="button" href="shop.php">shopping now</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider2.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h1>Dual Front</h1>
                                <h2>camera 20mp</h2>
                                <p>exclusive offer <span> 20% off </span> this week</p>
                                <a class="button" href="shop.php">shopping now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider3.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h1>Hurry Up!</h1>
                                <h2>IN THE WORD 2019</h2>
                                <p>exclusive offer <span> 20% off </span> this week</p>
                                <a class="button" href="shop.php">shopping now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--slider area end-->

    <!--shipping area start-->
    <section class="shipping_area mb-70">
        <div class="container">
            <div class=" row">
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping1.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Free Shipping</h2>
                            <p>Free shipping on all US order</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping2.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Support 24/7</h2>
                            <p>Contact us 24 hours a day</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping3.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>100% Money Back</h2>
                            <p>You have 30 days to Return</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping4.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Payment Secure</h2>
                            <p>We ensure secure payment</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--shipping area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner1.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner2.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner3.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--product area start-->
    <section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Hot Products</h2>
                    </div>
                </div>
            </div>
            <div class="product_carousel product_column5 owl-carousel">
				<?php
	                             $q4="SELECT * FROM product ";
							     $r4=mysqli_query($con,$q4);
							     while($row1=mysqli_fetch_array($r4))
					 { ?>
				<form method="post">
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.php?p_id=<?php echo $row1['p_id'] ?>"><img src="<?php echo $row1['image'] ?>" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="index.php?wish=<?php echo $row1['p_id']; ?>" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="cart_submit">
							<button type="submit" name="cart1<?php echo $row1['p_id'] ?>">Add to Cart</button>
							</div>
                        </div>
                        <figcaption class="product_content">
                            <div class="price_box">
                                <span class="old_price">$<?php echo $row1['price'] ?></span>
                                <span class="current_price">$<?php echo $row1['sale_price'] ?></span>
                            </div>
                         <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row1['p_id'] ?>"><?php echo $row1['p_name'] ?></a></h3>
                        </figcaption>
                    </figure>
                </article>
				</form>
				<?php 
						 $pid=$row1['p_id'];
					  	 $qty=$row1['quantity'];
					if(isset($_REQUEST['cart1'.$pid]))	{
						$uid=$_SESSION['SESS_ID'];
						$o_id=0;
						if($row1['sale_price']<=0) {
							$p_price=$row1['price'];
						}
						else{
							$p_price=$row1['sale_price'];
						}
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,order_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('index.php')</script>";
					} 
						 ?>
				<?php }?>
				<?php 
					  if(isset($_GET['wish'])){
						  $pid=$_GET['wish'];
						  $uid=$_SESSION['SESS_ID'];
						  
						  $qrr= "INSERT INTO wishlist(id,u_id,p_id)VALUES(NULL,'$uid','$pid')";
						mysqli_query($con,$qrr);
						  echo "<script> window.location.replace('index.php')</script>";
					  } ?>
            </div>
        </div>
    </section>
    <!--product area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner4.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner5.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--top- category area start-->
    <section class="top_category_product mb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3">
                    <div class="top_category_header">
                        <h3>Top Categories This Week</h3>
                        <p>Aliquam eget consectetuer habitasse interdum.</p>
                        <a href="shop.php">Show All Categories</a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-9">
                    <div class="top_category_container category_column5 owl-carousel">
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.php"><img src="assets/img/s-product/category1.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.php">Games & Consoles </a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--top- category area end-->

    <!--featured product area start-->
    <section class="featured_product_area mb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Featured Products</h2>
                    </div>
                </div>
            </div>
            <div class="row featured_container featured_column3">
				<?php
	                             $q5="SELECT * FROM product ";
							     $r5=mysqli_query($con,$q5);
							     while($row2=mysqli_fetch_array($r5))
					 { ?>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                          <a class="primary_img" href="product-details.php?p_id=<?php echo $row2['p_id'] ?>"><img
                                        src="<?php echo $row2['image'] ?>" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            </div>
                            <figcaption class="product_content">
                                <div class="price_box">
                                    <span class="current_price">$<?php echo $row2['price'] ?></span>
                                </div>
                         <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row2['p_id'] ?>"><?php echo $row1['p_name'] ?></a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.php" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
				<?php } ?>
            </div>
        </div>
    </section>
    <!--featured product area end-->

    <!--product area start-->
    <section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Computer & Laptop</h2>
                    </div>
                </div>
            </div>
            <div class="product_carousel product_column5 owl-carousel">
				<?php
	                             $q6="SELECT * FROM product ";
							     $r6=mysqli_query($con,$q6);
							     while($row3=mysqli_fetch_array($r6))
					 { ?>
				<form></form>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.php?p_id=<?php echo $row3['p_id'] ?>"><img
                                    src="<?php echo $row3['image'] ?>" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.php" title="Add to Wishlist"><i
                                                class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.php" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                            <div class="price_box">
                                <span class="old_price">$<?php echo $row3['price'] ?></span>
                                <span class="current_price">$<?php echo $row3['sale_price'] ?></span>
                            </div>
                            <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row3['p_id'] ?>"><?php echo $row3['p_name'] ?></a></h3>
                        </figcaption>
                    </figure>
                </article>
				<?php } ?>
            </div>
        </div>
    </section>
    <!--product area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-9">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner6.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner7.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--product area start-->
    <section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="product_left_area">
                        <div class="section_title">
                            <h2>Smartphone & Tablets</h2>
                        </div>
                        <div class="product_carousel product_column4 owl-carousel">
							<?php
	                             $q7="SELECT * FROM product ";
							     $r7=mysqli_query($con,$q7);
							     while($row7=mysqli_fetch_array($r7))
					 { ?>
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                           <a class="primary_img" href="product-details.php?p_id=<?php echo $row7['p_id'] ?>"><img src="<?php echo $row7['image'] ?>" alt=""></a>
                                            <span class="label_sale">sale</span>
                                        <div class="action_links">
                                            <ul>
                                                <li class="wishlist"><a href="wishlist.php" title="Add to Wishlist"><i
                                                            class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                                <li class="compare"><a href="#" title="compare"><span
                                                            class="ion-levels"></span></a></li>
                                            </ul>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="cart.php" title="add to cart">Add to cart</a>
                                        </div>
                                    </div>
                                    <figcaption class="product_content">
                                        <div class="price_box">
                                            <span class="old_price">$<?php echo $row7['price'] ?></span>
                                            <span class="current_price">$<?php echo $row7['sale_price'] ?></span>
                                        </div>
                           <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row7['p_id'] ?>"><?php echo $row7['p_name'] ?></a></h3>
                                    </figcaption>
                                </figure>
                            </article>
							<?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--product area end-->

    <!--blog area start-->
    
    <!--blog area end-->

    <!--brand area start-->
    <div class="brand_area mb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="brand_container owl-carousel">
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand2.jpg" alt=""></a>
                            </div>
                        </div>
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand3.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand4.jpg" alt=""></a>
                            </div>
                        </div>
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand5.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand6.jpg" alt=""></a>
                            </div>
                        </div>
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand7.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand8.jpg" alt=""></a>
                            </div>
                        </div>
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand9.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand10.jpg" alt=""></a>
                            </div>
                        </div>
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand2.jpg" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand3.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--brand area end-->

     <?php include('footer.php') ?>

    <!-- modal area start-->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">
                                    <div class="tab-content product-details-large">
                                        <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product1.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab2" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product2.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab3" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product3.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab4" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product5.jpg" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal_tab_button">
                                        <ul class="nav product_navactive owl-carousel" role="tablist">
                                            <li>
                                                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab"
                                                    aria-controls="tab1" aria-selected="false"><img
                                                        src="assets/img/product/product1.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab2" role="tab"
                                                    aria-controls="tab2" aria-selected="false"><img
                                                        src="assets/img/product/product2.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link button_three" data-toggle="tab" href="#tab3"
                                                    role="tab" aria-controls="tab3" aria-selected="false"><img
                                                        src="assets/img/product/product3.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab4" role="tab"
                                                    aria-controls="tab4" aria-selected="false"><img
                                                        src="assets/img/product/product5.jpg" alt=""></a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2>Handbag feugiat</h2>
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price">$64.99</span>
                                        <span class="old_price">$78.99</span>
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste
                                            laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam
                                            in quos qui nemo ipsum numquam, reiciendis maiores quidem aperiam, rerum vel
                                            recusandae </p>
                                    </div>
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                            <h2>size</h2>
                                            <select class="select_option">
                                                <option selected value="1">s</option>
                                                <option value="1">m</option>
                                                <option value="1">l</option>
                                                <option value="1">xl</option>
                                                <option value="1">xxl</option>
                                            </select>
                                        </div>
                                        <div class="variants_color">
                                            <h2>color</h2>
                                            <select class="select_option">
                                                <option selected value="1">purple</option>
                                                <option value="1">violet</option>
                                                <option value="1">black</option>
                                                <option value="1">pink</option>
                                                <option value="1">orange</option>
                                            </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form action="#">
                                                <input min="0" max="100" step="2" value="1" type="number">
                                                <button type="submit">add to cart</b>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal area end-->

    <!-- JS
============================================ -->

    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>


<!-- Mirrored from demo.hasthemes.com/junko-preview/junko/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 10:46:52 GMT -->
</html>