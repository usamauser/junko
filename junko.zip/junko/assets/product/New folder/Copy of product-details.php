<?php session_start();?>
<?php
$pid =$_GET['p_id'];
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - product details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>product details</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--product details start-->
    <div class="product_details mt-60 mb-60">
        <div class="container">
            <div class="row">
				<?php
	                              $q7="SELECT * FROM product WHERE p_id='$pid' AND status = '1'";
							      $r7=mysqli_query($con,$q7);
							      while($row7=mysqli_fetch_array($r7))
								  { ?>
                <div class="col-lg-6 col-md-6">
                    <div class="product-details-tab">
                        <div  class="zoomWrapper single-zoom">
                            <a href="#"><img  src="<?php echo $row7['image']?>"
                            </a>
                        </div>
                        <div class="single-zoom-thumb">
                            <ul class="s-tab-zoom owl-carousel single-product-active" id="gallery_01">
								<?php
	                              $q3="SELECT * FROM product_images WHERE p_id='$pid'";
							      $r3=mysqli_query($con,$q3);
							      while($row1=mysqli_fetch_array($r3))
								  { ?>
                                <li>
                                    <a href="#" class="elevatezoom-gallery active"> <img src="<?php echo $row1['image']?>" alt="" />
                                    </a>

                                </li>
								<?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
				<?php } ?>
					<?php
	                              $q8="SELECT * FROM product  WHERE p_id='$pid' AND status = '1'";
							      $r8=mysqli_query($con,$q8);
							      while($row8=mysqli_fetch_array($r8))
								  { ?>
                <div class="col-lg-6 col-md-6">
                    <div class="product_d_right">
                        <form method="post">

                            <h1><?php echo $row8['p_name']?></h1>
                            <div class="product_nav">
                                <ul>
                                    <li class="prev"><a href="#"><i class="fa fa-angle-left"></i></a></li>
                                    <li class="next"><a href="#"><i class="fa fa-angle-right"></i></a></li>
                                </ul>
                            </div>
                            <div class=" product_ratting">
                                <ul>
                                    <li><a href="#"><i class="fa fa-star"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star"></i></a></li>
                                    <li class="review"><a href="#">Reviews(<?php echo $row8['review']?>)</a></li>
                                </ul>

                            </div>
                            <div class="price_box">
                                <span class="current_price">$<?php echo $row8['sale_price']?></span>
                                <span class="old_price">$<?php echo $row8['price']?></span>

                            </div>
                            <div class="product_desc">
                                <p><?php echo $row8['description']?></p>
                            </div>
                            <div class="product_variant color">
                                <label>Availibility: <?php $quantity =$row8['quantity'];
								    if($quantity>0)
									{
										echo "In Stock";
									}
								   else
								   {
									   echo "Out of Stock";
								   }
								   ?></label>
                            </div>
                            <div class="product_variant quantity">
                                <label><span>quantity: <?php echo $row8['quantity']?></label></span>
                                <input name="qnty1" type="text">
                                <button class="button" type="submit" name="cart2<?php echo $row8['p_id']; ?>">add to cart</button>
                            </div>
                            <div class=" product_d_action">
                                <ul>
                                    <li><a href="#" title="Add to wishlist">+ Add to Wishlist</a></li>
                                    <li><a href="#" title="Add to wishlist">+ Compare</a></li>
                                </ul>
                            </div>
                            <div class="product_meta">
                                <span>Category: <a href="#"><?php echo $catgry=$row8['cat_id'];
									$q9="SELECT * FROM category WHERE cat_id='$catgry'";
							      $r9=mysqli_query($con,$q9);
							      while($row9=mysqli_fetch_array($r9))
								  { 
									
									  echo $row9['name'];
								  }
								  ?></a></span>
                            </div>
                        </form>
                        <?php
						$pid1=$row8['p_id'];
						$qty=$row8['quantity'];
					if(isset($_REQUEST['cart2'.$pid1]))	{
						$uid=$_SESSION['SESS_ID'];
						$o_id=0;
						if($row8['sale_price']<=0) {
							$p_price=$row8['price'];
						}
						else{
							$p_price=$row8['sale_price'];
						}
						$p_qty=$_REQUEST['qnty1'];
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						$qr= "INSERT INTO cart(id,u_id,order_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid1','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid1'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('shop.php')</script>";
					} 
						 ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--product details end-->

    <!--product info start-->
    <div class="product_d_info mb-60">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="product_d_inner">
                        <div class="product_info_button">
                            <ul class="nav" role="tablist">
                                <li>
                                    <a class="active" data-toggle="tab" href="#info" role="tab" aria-controls="info"
                                        aria-selected="false">Description</a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#sheet" role="tab" aria-controls="sheet"
                                        aria-selected="false">Specification</a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews"
                                        aria-selected="false">Review(<?php echo $row8['review'];?>)</a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="info" role="tabpanel">
                                <div class="product_info_content">
                                    <p><?php echo $row8['description']?></p>
                                    
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sheet" role="tabpanel">
                                <div class="product_d_table">
                                    <form method="post">
                                        <table>
                                            <tbody>
												<?php
	                              $q10="SELECT * FROM product_spec WHERE p_id='$pid'";
							      $r10=mysqli_query($con,$q10);
							      while($row2=mysqli_fetch_array($r10))
								  { ?>
                                                <tr>
                                              <td class="first_child"><?php echo $row2['name']?></td>
                                               <td><?php echo $row2['details']?></td>
                                                </tr>
												<?php } ?>
                                            </tbody>
                                        </table>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane fade"  role="tabpanel">
                                <div class="reviews_wrapper">
									<?php
	                              $q4="SELECT * FROM reviews";
							      $r2=mysqli_query($con,$q4);
							      while($row3=mysqli_fetch_array($r2))
								  { ?>
                                    <div class="reviews_comment_box">
                                        <div class="comment_text">
                                            <div class="reviews_meta">
                                                <div class="star_rating">
													<p><?php echo $row3['review'] ?></p>
                                                    <ul>
                                                        <li><a href="#"><i class="ion-ios-star"></i></a></li>
                                                        <li><a href="#"><i class="ion-ios-star"></i></a></li>
                                                        <li><a href="#"><i class="ion-ios-star"></i></a></li>
                                                        <li><a href="#"><i class="ion-ios-star"></i></a></li>
                                                        <li><a href="#"><i class="ion-ios-star"></i></a></li>
                                                    </ul>
                                                </div>
                                                <p><strong><?php echo $row3['name']?></strong></p>
												<p><?php echo $row3['date']?></p>
                                                <span><?php echo $row3['des']?></span>
                                            </div>
                                        </div>

                                    </div>
									<?php } ?>
                                    <div class="comment_title">
                                        <h2>Add a review </h2>
                                        <p>Your email address will not be published. Required fields are marked </p>
                                    </div>
                                    <div class="product_ratting mb-10">
                                        <h3>Your rating</h3>
                                        <ul>
                                            <li><a href="#"><i class="fa fa-star"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product_review_form">
                                        <form method="post">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label for="review_comment">Your review </label>
                                                    <textarea name="comment" id="review_comment"></textarea>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label for="author">Name</label>
                                                    <input id="author" name="name" type="text">

                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label for="email">Email </label>
                                                    <input id="email" name="email" type="text">
                                                </div>
                                            </div>
                                            <button name="btn4" type="submit">Submit</button>
                                        </form>
										<?php 
						     
							if(isset($_REQUEST['btn4']))
							{
								$des = $_REQUEST['comment'];
								$name = $_REQUEST['name'];
								$email = $_REQUEST['email'];
								$review = $_REQUEST['review'];
								$date = date('j/M/Y');

								$insert4 = "INSERT INTO 
								reviews(u_id,des,name,email,review,date) VALUES (NULL,'$name','$review','$des','$email','$date')";
								mysqli_query($con,$insert4);
								echo "<script>window.location.replace('shop.php')</script>";
							}
	                   ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--product info end-->
		<?php } ?>
    <!--product area start-->
    <section class="product_area related_products">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Related Products </h2>
                    </div>
                </div>
            </div>
            <div class="product_carousel product_column5 owl-carousel">
                <?php
	                             $q5="SELECT * FROM product ";
							     $r5=mysqli_query($con,$q5);
							     while($row4=mysqli_fetch_array($r5))
					 { ?>
				<article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.php?p_id=<?php echo $row4['p_id'] ?>"><img src="<?php echo $row4['image'] ?>" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.php" title="Add to Wishlist"><i
                                                class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="cart_submit">
							<button type="submit" name="cart1<?php echo $row4['p_id'] ?>">Add to Cart</button>
							</div>
                        </div>
                        <figcaption class="product_content">
                            <div class="price_box">
                                <span class="old_price">$<?php echo $row4['price'] ?></span>
                                <span class="current_price">$<?php echo $row4['sale_price'] ?></span>
                            </div>
                         <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row4['p_id'] ?>"><?php echo $row4['p_name'] ?></a></h3>
                        </figcaption>
                    </figure>
                </article>
				<?php } ?>
                
            </div>
        </div>
    </section>
    <!--product area end-->

    <!--product area start-->
    <section class="product_area upsell_products">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Upsell Products </h2>
                    </div>
                </div>
            </div>
            <div class="product_carousel product_column5 owl-carousel">
                <?php
	                             $q6="SELECT * FROM product ";
							     $r4=mysqli_query($con,$q6);
							     while($row5=mysqli_fetch_array($r4))
					 { ?>
				<article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.php?p_id=<?php echo $row5['p_id']; ?>"><img src="<?php echo $row5['image'] ?>" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.php" title="Add to Wishlist"><i
                                                class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="cart_submit">
							<button type="submit" name="cart1<?php echo $row5['p_id'] ?>">Add to Cart</button>
							</div>
                        </div>
                        <figcaption class="product_content">
                            <div class="price_box">
                                <span class="old_price">$<?php echo $row5['price'] ?></span>
                                <span class="current_price">$<?php echo $row5['sale_price'] ?></span>
                            </div>
                         <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row5['p_id'] ?>"><?php echo $row5['p_name'] ?></a></h3>
                        </figcaption>
                    </figure>
                </article>
				<?php } ?>
            </div>
        </div>
    </section>
    <!--product area end-->


    <?php include('footer.php') ?>

    <!-- modal area start-->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">
                                    <div class="tab-content product-details-large">
                                        <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product1.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab2" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product2.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab3" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product3.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab4" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product5.jpg" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal_tab_button">
                                        <ul class="nav product_navactive owl-carousel" role="tablist">
                                            <li>
                                                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab"
                                                    aria-controls="tab1" aria-selected="false"><img
                                                        src="assets/img/product/product1.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab2" role="tab"
                                                    aria-controls="tab2" aria-selected="false"><img
                                                        src="assets/img/product/product2.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link button_three" data-toggle="tab" href="#tab3"
                                                    role="tab" aria-controls="tab3" aria-selected="false"><img
                                                        src="assets/img/product/product3.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab4" role="tab"
                                                    aria-controls="tab4" aria-selected="false"><img
                                                        src="assets/img/product/product5.jpg" alt=""></a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2>Handbag feugiat</h2>
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price">$64.99</span>
                                        <span class="old_price">$78.99</span>
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste
                                            laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam
                                            in quos qui nemo ipsum numquam, reiciendis maiores quidem aperiam, rerum vel
                                            recusandae </p>
                                    </div>
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                            <h2>size</h2>
                                            <select class="select_option">
                                                <option selected value="1">s</option>
                                                <option value="1">m</option>
                                                <option value="1">l</option>
                                                <option value="1">xl</option>
                                                <option value="1">xxl</option>
                                            </select>
                                        </div>
                                        <div class="variants_color">
                                            <h2>color</h2>
                                            <select class="select_option">
                                                <option selected value="1">purple</option>
                                                <option value="1">violet</option>
                                                <option value="1">black</option>
                                                <option value="1">pink</option>
                                                <option value="1">orange</option>
                                            </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form action="#">
                                                <input min="0" max="100" step="2" value="1" type="number">
                                                <button type="submit">add to cart</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal area end-->

    <!-- JS
============================================ -->

    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>


<!-- Mirrored from demo.hasthemes.com/junko-preview/junko/product-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 10:47:01 GMT -->
</html>