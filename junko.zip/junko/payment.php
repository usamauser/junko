<?php session_start(); 
if(isset($_GET['msg']))
{
	$checkouid=$_GET['msg'];
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - payment page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>
	
	<div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.phpl">home</a></li>
							<li><a href="checkout.php">checkout</a></li>
                            <li>Payment</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<!--Payment Details-->
	<section>
	<div class="container">
	  <div class="ps-section__header">
                    <h3 >Payment Details</h3>
                </div>
	<div class="Checkout_section mt-60">
		<div class="container"> 
			<div class="checkout_form">
				 <div class="row">
					 <div class="col-lg-6 col-md-6">
		 			<form method="post">
								<h3 class="cart_total" style="margin-right: 25px;" >Payment Method</h3>
									<div class="row">
                                        <div class="ps-block--payment-method" >
                                            <div class="ps-tabs" >
                                                <div class="ps-tab active" >
													<?php
															$uid= $_SESSION['SESS-ID'];
													   $ch = "SELECT * FROM register WHERE u_id='$uid'";
													   $rr=mysqli_query($con,$ch);
													   while($row=mysqli_fetch_array($rr))
													   { ?>	
                                                        <div class="form-group">
                                                            <label>Name on card*</label>
                                                            <input class="form-control" type="text" placeholder="" value="" name="name" required>
                                                        </div>
														
                                                        <div class="form-group">
                                                            <label>Card number*</label>
                                                            <input class="form-control" type="text" name="card" placeholder="" value="" required>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-8">
                                                                <div class="form-group">
                                                                    <label>Experation Date*</label>
                                                                    <div class="row">
                                                                        <div class="col-6">
                                                                            <div class="form-group">
                                                                                <select class="form-control" name="month" required>
																				
																					<option>Select Month</option>
																					<?php 
														                        for($x=1; $x<=12; $x++)
																				{ ?>
																					<option><?php echo $x; ?></option>
																			<?php } ?>
																					
																				</select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <div class="form-group">
                                                                                <select class="form-control" name="year" required >
																				
																					<option>Select Year</option>
																					<?php 
														                        for($x=2018; $x<=2028; $x++)
																				{ ?>
																					<option><?php echo $x; ?></option>
																			<?php } ?>
																					
																				</select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-4">
                                                                <div class="form-group">
                                                                    <label>CVC*</label>
                                                                    <input class="form-control" name="cvv" type="password" maxlength="3" placeholder="Security Code" required>
                                                                </div>
                                                            </div>
                                                        </div>
													<?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="col-lg-6 col-md-6">
									<h3>Order Details</h3>
									<div class="order_table table-responsive">
								 <table>
                                    <thead>
                                            <th>Product</th>
                                            <th>Total</th>
                                    </thead>
                                    <tbody>
										<?php
							            $uid=$_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM cart WHERE status = '0' AND u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>	
                                        <tr>
                                            <td class="product_name"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a><strong> × <?php echo $row['p_qty'] ?></strong></td>
                                            <td class="product-price">$<?php echo $row['p_price'] ?></td>
										</tr>
										<?php } } ?>
                                    </tbody>
								   </table>
								<br>
                                            <h4 class="cart_subtotal">Cart Subtotal<span>$
												<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(p_total) as p_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['p_tot'];
										}?>
										</span></h4>
								<br>
                                        <h3 class="cart_total">Order Total<span>$
												<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(g_total) as g_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['g_tot'];
										}?>
											</span></h3>
                                       
                            </div>
										<div class="payment_method">
                                		<div class="order_button">
                                   	 <button type="submit" name="btn7" >Proceed to Payment</button>
                                		</div>
                            		</div>
							</form>
						 <?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT * FROM checkout WHERE u_id='$uid' AND status='0'";
										$sumr=mysqli_query($con,$sum);
										while($sumrr=mysqli_fetch_array($sumr))
										{
											if(isset($_REQUEST['btn7']))
											{
											$total= $sumrr['total'];
											$id=$_SESSION['SESS-ID'];
											$name=$_REQUEST['name'];
											$card=$_REQUEST['card'];
											$expiry=$_REQUEST['month']."/".$_REQUEST['year'];
											$cvv=$_REQUEST['cvv'];	
											$status= 0;
											$date=date('j/M/Y');
											
											$insert="INSERT INTO payment(payment_id,o_id,u_id,total_price,date,name,card_no,expiry_date,cvv,status)
											VALUES(null, '$checkouid',$uid,'$total','$date','$name','$card','$expiry','$cvv','$status')";	
											mysqli_query($con,$insert);
											$q= "SELECT * FROM checkout WHERE u_id='$uid' AND status='0' ORDER BY o_id DESC LIMIT 0,1";
											$qry=mysqli_query($con,$q);
											$r=mysqli_fetch_array($qry);
											$invoice=$r['o_id'];
												
												
											//////////////////////// EMAIL SENDING ///////////////////////
									$x = '';
									$uid= $_SESSION['SESS-ID'];
	                                $ch11 = "SELECT * FROM cart WHERE u_id='$uid' AND status='0'";
								   $rr11=mysqli_query($con,$ch11);
								   while($row1=mysqli_fetch_array($rr11))
								   {
									   $pid=$row1['p_id'];
									   $qry1 = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r12=mysqli_query($con,$qry1);
								   while($r1=mysqli_fetch_array($r12))
								   {
							
					              $x.= "<tr style='padding: 20px;' align='center'>" ;
								  $x.= "<td style='padding: 5px;'>".$row1['id']."</td>";
								  $x.= "<td style='padding: 5px;'>".$r1['p_name']."</td>" ;
								  $x.= "<td style='padding: 5px;'>".$row1['p_price']."</td>"; 
								  $x.= "<td style='padding: 5px;'>".$row1['p_qty']."</td>"; 
								  $x.= "<td style='padding: 5px;'>".$row1['p_total']."</td>" ;
								  $x.="</tr>" ;
						       
						   
					  } }
												
												
										
										    $subject="Test";
										    $header='From: support@atif.delogiccoder.com' . "\r\n" .
										    'Reply-To: support@atif.delogiccoder.com' . "\r\n" .
										    'X-Mailer: PHP/' . phpversion() . "\r\n" .
										    'Content-type: text/html; charset=iso-8859-1';
										    $name1=$sumrr['f_name']." ".$sumrr['l_name'];
										    $addr=$sumrr['address'].", ".$sumrr['city'].", ".$sumrr['state'].", ".$sumrr['country'];
										    $ph=$sumrr['phone'];
											$ema=$sumrr['email'];	
											$total1= $sumrr['total']-10;
											$zero=0;
												
										    $body='<div class="container" style="padding: 40px;">

														<div class="row" style="margin-bottom: 20px;">
														<div class="col-12" align="center">
															<div class="jumbotron" style="background-color:#1953b4; padding: 20px;">
												<h1 style="color: white;">Thanks for order, '. $name1.'</h1>
												<p style="color: white;">We will mail you again when to let you know when your order ships.</p>
											</div>
														</div>
													</div>


														<div class="row">
														<div class="col-lg-6 col-md-6 col-sm-12" align="left">
															<span style="color:#888888">Ship to:</span>
														   <h2 style="color: black;"> '. $name1.'</h2>
															<p style="color: black;"> '. $addr.'<br>'.$ph.'<br>'.$ema.'</p>
														</div>
														<div class="col-lg-6 col-md-6 col-sm-12" align="right">
														   <h1 style="color:#1953b4;">Invoice: #'.$checkouid.'</h1>
															<p style="color: black;">Date: '.$date.'</p>
														</div>
													</div>
													<hr style=" width: 100%; border: 1px solid #1953b4; margin-bottom: 20px;" />
													 <table style="width: 100%; padding: 20px;">
					  <thead>
						  <tr style="background-color:#1953b4; color: white; padding: 20px;">
						   <th style="padding: 5px;">#</th>
						   <th style="padding: 5px;">Product</th>
						   <th style="padding: 5px;">Price</th>	  
						   <th style="padding: 5px;">Quantity</th>
						   <th style="padding: 5px;">Total</th>	  
						  </tr>
					  </thead>
						  <tbody>
						  '. $x .'
						 </tbody> </table>
														<hr style=" width: 100%; border: 1px solid #1953b4; margin-bottom: 20px;" />
												
														<div class="row" style="margin-top: 20px;">
															<div class="col-lg-12 col-md-12 col-sm-12" align="right">
														   <h3 style="color: black;">Total: $'.$total1.'</h3>
														   <h3 style="color: black;">Shipping: $10</h3>
														   <h3 style="color: black;">Grand Total: $'.$total.'</h3>		
														</div>
															</div>

														<hr style=" width: 100%; border: 1px solid #1953b4; margin-bottom: 20px;" />

														<div class="row" style="margin-top: 5px;">
															<div class="col-lg-12 col-md-12 col-sm-12" align="center">
														   <h4 style="color:#888888">Thank you Dear! '. $name1.' for ordering products from Junko.</h4>
														</div>
															</div>




													</div>	


											  </body>
										   </html>
										   
										   ';
												mail ($ema,$subject,$body,$header);		
											/////////////////////////////////////////////////////////////
												
												
											$update="UPDATE cart SET o_id='$invoice', status='1' WHERE u_id='$uid' AND status='0'";
											mysqli_query($con,$update);
											
											echo "<script>window.location.replace('order_success.php?msg=$invoice')</script>";
											
										}
											
										}
										
										?>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		</div>
	
	
	
	
	</section>
	
	<?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
	
</body>
</html>