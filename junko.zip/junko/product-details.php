<?php session_start(); ?>
<?php
$pid =$_GET['p_id'];
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - product details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
	
	.btn-outline-info {
    color: #1953b4;
    border-color: #1953b4;
}
	.btn-outline-info:hover
	{background-color: #1953b4;
		border-color: ##1953b4;
	}
	
	
	</style>
<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>product details</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--product details start-->
    <div class="product_details mt-60 mb-60">
        <div class="container">
            <div class="row">
				<?php
	                              $q7="SELECT * FROM product WHERE p_id='$pid' AND status = '1'";
							      $r7=mysqli_query($con,$q7);
							      while($row7=mysqli_fetch_array($r7))
								  { ?>
                <div class="col-lg-6 col-md-6">
                    <div class="product-details-tab">
                        <div  class="zoomWrapper single-zoom">
                            <a href="product-details.php?p_id=<?php echo $row7['p_id'] ?>"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row7['image'])?>"</a>
                            
                        </div>
                        <div class="single-zoom-thumb">
                            <ul class="s-tab-zoom owl-carousel single-product-active" id="gallery_01">
								<?php
	                              $q3="SELECT * FROM product_images WHERE p_id='$pid'";
							      $r3=mysqli_query($con,$q3);
							      while($row1=mysqli_fetch_array($r3))
								  { ?>
                                <li>
                                    <a href="product-details.php?p_id=<?php echo $row1['p_id'] ?>" class="elevatezoom-gallery active"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row1['image'])?>" alt="" />
                                    </a>

                                </li>
								<?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
				<?php } ?>
					<?php
	                              $q8="SELECT * FROM product  WHERE p_id='$pid' AND status = '1'";
							      $r8=mysqli_query($con,$q8);
							      while($row8=mysqli_fetch_array($r8))
								  { ?>
                <div class="col-lg-6 col-md-6">
                    <div class="product_d_right">
                        <form method="post">

                            <h1><a href="product-details.php?p_id=<?php echo $row8['p_id'] ?>"><?php echo $row8['p_name']?></a></h1>
                            
                            <div class="price_box">
                                <span class="current_price">$<?php $g=$row8['sale_price'];
								   if($g<=0)
											   {
												  echo $row8['price'];
												   
											   }
										       else
											   {
												  echo $row8['sale_price']; 
												   
											   }
									?></span>
                            </div>
                            <div class="product_desc">
                                <p><?php echo $row8['description']?></p>
                            </div>
                            <div class="product_variant color">
                                <label>Availibility: <?php $quantity =$row8['quantity'];
								    if($quantity>0)
									{
										echo "In Stock";
									}
								   else
								   {
									   echo "Out of Stock";
								   }
								   ?></label>
                            </div>
                            <div class="product_variant quantity">
                                <label>quantity: <?php echo $row8['quantity'] ?></label>
                                <input name="qnty1" type="text">
								<?php if(isset($_SESSION['SESS-ID'])){?>
                                <button  style="background: none; border: none;" type="submit" name="cart2<?php echo $row8['p_id'] ?>"><a class="btn btn-outline-info"  data-toggle="tooltip" data-placement="top" title="Add To Cart"> Add to cart</a></button>
								<?php } else {?>
								<div class="add_to_cart">
										<a href="login.php"  title="Login to Add To Cart">Add to cart</a>
										</div>
											<?php } ?>
                            </div>
                            <div class=" product_d_action">
                                <ul><li>
								<?php if(isset($_SESSION['SESS-ID'])){?>
								<button style="background: none; border: none;" type="submit" name="wish1<?php echo $row8['p_id'] ?>"><a class="fa fa-heart-o" data-toggle="tooltip" data-placement="top" title="Add to Whishlist"></a></button>
								<?php } else {?>
								<a href="login.php" title="Login for Add to Wishlist"><i class="fa fa-heart" aria-hidden="true"></i></a>
								<?php } ?>
								</li></ul>
                            </div>
                            <div class="product_meta">
                                <span>Category: <a href="product-details.php?p_id=<?php echo $row8['p_id'] ?>">
									<?php 
									   $catgry=$row8['cat_id'];
									$q9="SELECT * FROM category WHERE cat_id='$catgry'";
							      $r9=mysqli_query($con,$q9);
							      while($row9=mysqli_fetch_array($r9))
								  { 
									
									  echo $row9['name'];
								  }
								  ?></a></span>
                            </div>
							<div class="product_meta">
                                <span>Brand: <a href="product-details.php?p_id=<?php echo $row8['p_id'] ?>">
									<?php 
									   $brand=$row8['brand_id'];
									$q99="SELECT * FROM brand WHERE brand_id='$brand'";
							      $r99=mysqli_query($con,$q99);
							      while($row99=mysqli_fetch_array($r99))
								  { 
									
									  echo $row99['name'];
								  }
								  ?></a></span>
                            </div>
							<div class="product_meta">
                                <span>Sold By: <a href="product-details.php?p_id=<?php echo $row8['p_id'] ?>">
									<?php 
									   $pid=$row8['p_id'];
									$q91="SELECT * FROM product WHERE p_id='$pid'";
							      $r91=mysqli_query($con,$q91);
							      while($row91=mysqli_fetch_array($r91))
								  { 
									
									  echo $row91['sold_by'];
								  }
								  ?></a></span>
                            </div>
                        </form>
                        <?php
									
									$pid=$row8['p_id'];							
									if(isset($_REQUEST['wish1'.$pid]))
													   {
										                   $uid=$_SESSION['SESS-ID'];
															$qry1 = "SELECT * FROM wishlist WHERE u_id = '$uid' AND p_id = '$pid'";
																	$r1=mysqli_query($con,$qry1);
																	$row1 = mysqli_fetch_assoc($r1);
																	if((mysqli_num_rows($r1))>0)
																	{

																	}
																	else
																	{
                                                                            $q= "INSERT INTO wishlist (id, p_id,u_id) VALUES ( NULL, '$pid', '$uid')";
																			mysqli_query($con,$q);
																			echo "<script> window.location.replace('index.php')</script>";
																	}
																
													   }
										
								?>	
					<?php 
	                                  $pid=$row8['p_id'];
																
									  if(isset($_REQUEST['cart2'.$pid]))
									   {
										       $uid=$_SESSION['SESS-ID'];
											   $o_id=0;
										       if($row8['sale_price']<=0)
											   {
												  $p_price=$row8['price']; 
												   
											   }
										       else
											   {
												  $p_price=$row8['sale_price']; 
												   
											   }
										       
											  
										      $qry1 = "SELECT * FROM cart WHERE u_id = '$uid' AND p_id = '$pid' AND status='0'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
													$up="SELECT * FROM cart WHERE p_id='$pid' AND u_id='$uid'";
													$u=mysqli_query($con, $up);
													while($r=mysqli_fetch_array($u))
													{ 
													  $p_qty=$_REQUEST['qnty1']; 
													 $qnty=$r['p_qty']+$p_qty;
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $q = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
													 
													} 
													
												}
												else
												{
												       $p_qty=$_REQUEST['qnty1'];
													   $p_total=$p_price*$p_qty;
													   $p_tax=0;
													   $p_ship=0;
													   $g_total=$p_ship+$p_total+$p_tax; 
													   $status=0; 
													$q= "INSERT INTO cart (id, u_id, o_id, p_id, p_price, p_qty, p_total, p_tax, p_ship, g_total, status) VALUES ( NULL, '$uid', '$o_id', '$pid', '$p_price', '$p_qty', '$p_total', '$p_tax', '$p_ship', '$g_total', '$status')";
												}
											mysqli_query($con,$q);
										  	
										    $qty=$row8['quantity'];
										    $qty=$qty - $p_qty;
										  	$qry = "UPDATE product SET quantity = '$qty' WHERE  p_id ='$pid'";
					                     	mysqli_query($con,$qry);
										  echo"<script>window.location.replace('product-details.php?p_id=$pid')</script>";
									   }
									   ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--product details end-->

    <!--product info start-->
    <div class="product_d_info mb-60">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="product_d_inner">
                        <div class="product_info_button">
                            <ul class="nav" role="tablist">
                                <li>
                                    <a class="active" data-toggle="tab" href="#info" role="tab" aria-controls="info"
                                        aria-selected="false">Description</a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#sheet" role="tab" aria-controls="sheet"
                                        aria-selected="false">Specification</a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews"
                                        aria-selected="false">Review(<?php 
								  
								   $review="SELECT count(id) as countt FROM reviews WHERE p_id='$pid'";
								   $rew=mysqli_query($con,$review);
								   while($r6=mysqli_fetch_array($rew))
								   { echo $r6['countt']; } ?>
										)</a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="info" role="tabpanel">
                                <div class="product_info_content">
                                    <p><?php echo $row8['description']?></p>
                                    
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sheet" role="tabpanel">
                                <div class="product_d_table">
                                    <form method="post">
                                        <table>
                                            <tbody>
												<?php
	                              $q10="SELECT * FROM product_spec WHERE p_id='$pid'";
							      $r10=mysqli_query($con,$q10);
							      while($row2=mysqli_fetch_array($r10))
								  { ?>
                                                <tr>
                                              <td class="first_child"><?php echo $row2['name']?></td>
                                               <td><?php echo $row2['details']?></td>
                                                </tr>
												<?php } ?>
                                            </tbody>
                                        </table>
                                    </form>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="reviews"  role="tabpanel">
                                <div class="reviews_wrapper">
									<?php
	                              $q4="SELECT * FROM reviews WHERE p_id='$pid'";
							      $r2=mysqli_query($con,$q4);
							      while($row3=mysqli_fetch_array($r2))
								  { ?>
                                    <div class="reviews_comment_box">
                                        <div class="comment_text">
                                            <div class="reviews_meta">
                                                <p><strong><?php echo $row3['name']?></strong></p>
												<p><?php echo $row3['date']?></p>
                                                <span><?php echo $row3['des']?></span>
                                            </div>
                                        </div>

                                    </div>
									<?php } ?>
                                    <div class="comment_title">
                                        <h2>Add a review </h2>
                                        <p>Your email address will not be published. Required fields are marked </p>
                                    </div>
                                    <div class="product_review_form">
                                        <form method="post">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label for="review_comment">Your review </label>
                                                    <textarea name="comment" id="review_comment"></textarea>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label for="author">Name</label>
                                                    <input name="name" type="text">

                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label for="email">Email </label>
                                                    <input name="email" type="text">
                                                </div>
                                            </div>
                                            <button name="btn4" type="submit">Submit</button>
                                        </form>
										<?php 
						     
							if(isset($_REQUEST['btn4']))
							{
								$des = $_REQUEST['comment'];
								$name = $_REQUEST['name'];
								$email = $_REQUEST['email'];
								$date = date('j/M/Y');
								$uid=$_SESSION['SESS_ID'];
								
								$insert4 = "INSERT INTO 
								reviews(id,des,name,email,date,p_id,u_id) VALUES (NULL,'$name','$des','$email','$date','$pid','$uid')";
								mysqli_query($con,$insert4);
								echo"<script>window.location.replace('product-details.php?p_id=$pid')</script>";
							}
	                   ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--product info end-->
		<?php } ?>
    <!--product area start-->
    
    <!--product area end-->

    <!--product area start-->
    
    <!--product area end-->


    <?php include('footer.php') ?>

    <!-- modal area start-->
    
    <!-- modal area end-->

    <!-- JS
============================================ -->

    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>


<!-- Mirrored from demo.hasthemes.com/junko-preview/junko/product-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 10:47:01 GMT -->
</html>